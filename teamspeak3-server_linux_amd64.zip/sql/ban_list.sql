select * from bans where server_id=:server_id:;
